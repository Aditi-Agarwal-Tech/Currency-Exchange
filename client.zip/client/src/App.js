import './App.css';
import Home from './components/Home.jsx';
import Login from "./components/Login.jsx";
function App() {
  return (
    <div className="App">
      {/* <Login/> */}
      <Home/>
    </div>
  );
}

export default App;
