import React from 'react';
import 'bootstrap-icons/font/bootstrap-icons.css';

function Home() {
  return (
    <div style={{backgroundColor:"#f7f7f7", height:"100%"}}>
      <div className="border-bottom h-25 py-2 px-5 d-flex gap-5 justify-content-end px-5">
        <div>
            Dark Mode
        </div>
        <div>
            Aditi
        </div>
      </div>
      <div className='mx-5 px-5 my-5'>
        <div className='my-3'>
            <h1 className='my-2' style={{color:"teal"}}>Exchange Currency widget</h1>
            <div className='blockquote my-1' style={{fontWeight:"10"}}>Real-time widget for Currency exchange</div>
        </div>
        <div className='border rounded my-3 px-3 py-2' style={{backgroundColor:"#ffffff"}}>
            <div className='row my-3 px-3 small'>Data as per records</div>
            <div className='row my-3 px-3'>
                <div className="col-5">
                    <h6 className='row'>I have</h6>
                    <div className='row' >
                        <div className='btn col border'>UAH</div>
                        <div className='btn col border'>AUD</div>
                        <div className='btn col border'>EUR</div>
                        <div className='btn col border'>USD</div>
                        <div className='btn col border'>NZD</div>
                        <div className='btn col border'>CHF</div>
                    </div>
                </div>
                <div className="col-2"></div>
                <div className="col-5">
                    <h6 className='row'>I want to buy</h6>
                    <div className='row' >
                        <div className='btn col border'>UAH</div>
                        <div className='btn col border'>AUD</div>
                        <div className='btn col border'>EUR</div>
                        <div className='btn col border'>USD</div>
                        <div className='btn col border'>NZD</div>
                        <div className='btn col border'>CHF</div>
                    </div>
                </div>
            </div>
            <div className="row my-3 px-3">
                <div className="col-5">
                    <div className="row my-2" style={{height:"100px", border:"1px solid teal", borderRadius:"5px"}}>
                        {/* todo currency input */}
                    </div>
                </div>
                <div className="col-2 d-grid justify-content-center align-items-center">
                    <div className="rounded d-flex justify-content-center" style={{backgroundColor:"grey", width:"25px", height:"25px"}}><i className="bi-arrow-left-right white"></i></div>
                </div>
                <div className="col-5">
                    <div className="row my-2" style={{height:"100px", border:"1px solid teal", borderRadius:"5px"}}>
                        {/* todo currency input */}
                    </div>
                </div>
            </div>
            <div className='row my-3 px-3'>
                <div className="col-5">
                    <div className='row rounded py-1 small' style={{background:"grey", color: "white"}}>
                        <div className="col-11">View Currency transfer history</div>
                        <i className="col-1 bi-clock"></i>
                    </div>
                </div>
                
            </div>
        </div>
      </div>
    </div>
    
  )
}

export default Home
